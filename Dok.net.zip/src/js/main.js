/**
  *
  *
  * @param {number}
  * @returns {number}
  */
